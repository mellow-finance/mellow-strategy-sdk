# SDK for creating new strategies on UniV3

## Getting started

```
python3 -m venv .venv
cp .env.example .env
pip install -r requirements.txt
```
